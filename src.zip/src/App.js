// App.js
import React from 'react';
import SignUp from './Signup';


const App = () => {
  return (
    <div>
      <h1>Firebase Authentication</h1>
      <SignUp/>
      
    </div>
  );
};

export default App;
